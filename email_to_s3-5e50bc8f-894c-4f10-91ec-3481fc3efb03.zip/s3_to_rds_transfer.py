import json
import psycopg2
import urllib
import boto3
import io
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import uuid
import time
import traceback
from datetime import datetime

from rename_dicts import RENAME_DICT
from messages import TIPS_MESSAGE, INCORRECT_COLUMNS_TIP, SUBJECT

S3 = boto3.client('s3')
SNS = boto3.client('sns')
TOPIC_ARN = 'arn:aws:sns:ap-south-1:993722675181:s3_to_rds_transfer_lambda_failed'

DATABASE = 'ipl_dl_new_automated'
USERNAME = 'postgres'
PASSWORD = 'Integrace2021'
HOST = 'ipl-dl-dev.cjdxjayjo0uv.ap-south-1.rds.amazonaws.com'
PORT = '5432'


def get_data_and_key_from_bucket(key, bucket):
    response = S3.get_object(Bucket=bucket, Key=key)
    data = response['Body'].read()
    df_list = []
    if key[-3:]== 'csv':
        df = pd.read_csv(io.BytesIO(data), encoding='latin-1', dtype=object)
        df_list.append(df)
    elif key[-3:]== 'xls':
        df = pd.read_excel(io.BytesIO(data), dtype=object)
        df_list.append(df)
    else:
        xl = pd.ExcelFile(io.BytesIO(data))
        sheet_names = xl.sheet_names
        if sheet_names == 1:
            df = pd.read_excel(io.BytesIO(data), engine='openpyxl', dtype=object)
            df_list.append(df)
        else:
            for sheet in sheet_names:
                df = pd.read_excel(io.BytesIO(data), sheet, engine='openpyxl', dtype=object)
                df_list.append(df)
                print(xl.sheet_names, "<-----------------------------------------------------------------------------------")
    print(df_list)
    return df_list


def send_column_missing_email(db_columns, file_columns, key):
    # Find out missing columns
    missing_columns = set(db_columns) - set(file_columns)
    missing_columns = str([s.replace('_', ' ').title() for s in missing_columns]).replace("'", '')[1:-1]
    db_columns = str([s.replace('_', ' ').title() for s in db_columns]).replace("'", '')[1:-1]
    
    # Print which email is being sent
    print('A missing columns email was sent:')
    print("Missing columns: ", missing_columns)
    
    # Find out the file and folder in S3
    folder = key.split('/')[0]
    file = key.split('/')[1]
    
    # Create and publish error message
    error_message = f"An error occured while uploading file '{file}' to folder '{folder}'. \n\n"
    missing_columns_message = f"We found that these columns are missing from your file: {missing_columns}. \n\n"
    
    message = error_message + missing_columns_message + TIPS_MESSAGE + INCORRECT_COLUMNS_TIP + db_columns
    # SNS.publish(TopicArn=TOPIC_ARN, Message=message, Subject=SUBJECT)
    print(message)
    return message


def send_dtype_error_email(irregularities, key):
    # Find out the file and folder in S3
    folder = key.split('/')[0]
    file = key.split('/')[1]
    
    # Create and publish error message
    error_message = f"An error occured while uploading file '{file}' to folder '{folder}'. \n\n"
    irregularities_error_message = "Found the following characters/letters in numeric columns: \n"
    irregularities_message_list = ""
    
    for irregularity in irregularities:
        field = irregularity["field"].replace('_', ' ').title()
        irregularities_message_list = irregularities_message_list + "- " + str(irregularity["irregularities"]) + " present in column: " + field + ". \n"
    
    message = error_message + irregularities_error_message + irregularities_message_list
    # SNS.publish(TopicArn=TOPIC_ARN, Message=message, Subject=SUBJECT)
    print(message)

  
def handle_multi_sheet_xl(df_list, existing_df_columns, table_name):
    print(set(existing_df_columns))
    list_of_useful_df = []
    list_of_columns_found = []
    
    for df in df_list:
        df = df.rename(columns=RENAME_DICT[table_name])
        print(set(list(df.columns)))
        if set(list(df.columns)) == set(existing_df_columns):
            list_of_useful_df.append(df)
            list_of_columns_found.extend(list(df.columns))
        else:
            print("missing columns: ", set(existing_df_columns) - set(list(df.columns)))
        
    if len(list_of_useful_df) == 1:
        df = list_of_useful_df[0]
    elif len(list_of_useful_df) > 1:
        print("number of dfs to append: ", len(list_of_useful_df))
        df = list_of_useful_df[0].append(list_of_useful_df[1:])
        print("appended df")
        print(df)
    
    return df, list_of_columns_found
   
    
def check_dtypes_and_return_irregularities(df, non_char_fields):
    irregularities = []
    for field in non_char_fields:
        irregularities_list = df.loc[~df[field].astype(str).str.replace('.', '').str.replace('-', '').str.replace('+', '').str.isnumeric(), field].tolist()
        irregularities_dict = {
            "field": field,
            "irregularities": irregularities_list,
        }
        if len(irregularities_list) > 0:
            irregularities.append(irregularities_dict)
    return irregularities


def match_columns_in_dfs(file_df, existing_df):
    file_columns = set(file_df.columns)
    existing_columns = set(existing_df.columns)
    # print(len(file_columns), file_columns)
    # print(len(existing_columns), existing_columns)
    extra_columns_in_file = file_columns - existing_columns
    missing_columns_in_file = existing_columns - file_columns
    
    if len(extra_columns_in_file) > 0:
        # print("All columns", set(file_df.columns)) 
        file_df = file_df.loc[:, (file_columns - extra_columns_in_file)]
        # print("Useful columns", set(file_df.columns)) 

    
    if len(missing_columns_in_file) > 0:
        # handle missing key columns
        file_df.loc[:, list(missing_columns_in_file)] = np.nan
        # print(file_df.loc[:, list(missing_columns_in_file)])
    
    numeric_column_list = list(existing_df.select_dtypes(include=['number']).columns)
    
    file_df[numeric_column_list] = file_df[numeric_column_list].fillna(0)
    return file_df, existing_df


def compare_and_append_df(existing_df, df_to_add, backup_df, key_columns):
    df_to_add, existing_df = match_columns_in_dfs(df_to_add, existing_df)
    
    df_to_add = df_to_add.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    existing_df = existing_df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    
    print(df_to_add.loc[:, key_columns])
    print(existing_df.loc[:, key_columns])
    
    merged_df = pd.merge(df_to_add.astype(str), existing_df.astype(str), on=key_columns, how="left", indicator=True)
    
    rename_dict = {}
    for col in list(df_to_add.columns):
        rename_dict[f"{col}_x"] = col
        
    merged_df = merged_df.rename(columns=rename_dict)
    l = list(df_to_add.columns)
    l.append("_merge")
    print(l)
    merged_df = merged_df.loc[:, l]
    
    
    df = merged_df.copy()
    df = df[df['_merge'] == 'left_only']
    
    update_df = merged_df.copy()
    update_df = update_df[update_df['_merge'] == 'both']
    
    # rename_dict = {}
    # for col in list(df_to_add.columns):
    #     rename_dict[f"{col}_x"] = col
    # df = df.rename(columns=rename_dict)
    # df = df.loc[:, list(df_to_add.columns)]
    
    print("existing, file df, new data df, update data df")
    print(existing_df.shape, df_to_add.shape, df.shape, update_df.shape)
    print(df)
    
    if existing_df.shape[0] == 0:
        max_id = 0
    else:
        max_id = int(backup_df['id'].astype(int).max())
    # print("\n\n\n\n max_id: ", max_id)
    len_of_df = int(df.shape[0])
    list_of_index = [i for i in range((max_id + 1), (max_id + len_of_df + 1))]
    # print(list_of_index[:100])
    
    df['id'] = list_of_index
    
    inner_df = pd.merge(df_to_add.astype(str), existing_df.astype(str), on=key_columns, how="inner", indicator=True)
    print(inner_df.shape)
    
    # rename_dict = {}
    # for col in list(df_to_add.columns):
    #     rename_dict[f"{col}_x"] = col
    # inner_df = inner_df.rename(columns=rename_dict)
    # inner_df = inner_df.loc[:, list(df_to_add.columns)]
    
    # print("update_df_shape")
    # print(inner_df.shape)
    
    # return df, inner_df
    df = df.loc[:, list(df_to_add.columns)]
    update_df = update_df.loc[:, list(df_to_add.columns)]
    
    return df, update_df


def send_data_to_db(df_list, key, table_name, key_columns):
    # Getting data from the database
    engine = create_engine(f'postgresql://{USERNAME}:{PASSWORD}@{HOST}:{PORT}/{DATABASE}')
    existing_df = pd.read_sql_table(table_name, engine)
    backup_df = existing_df.copy(deep=True)
    # existing_df = existing_df.fillna(0)
    
    
    db_columns = list(existing_df.columns)
    print("Printing columns found in db....")
    print(db_columns)
    
    if 'duplicate_count' in db_columns:
        db_columns.remove('duplicate_count')
    if 'id' in db_columns:
        db_columns.remove('id')
    if 'upload_date' in db_columns:
        db_columns.remove('upload_date')
    if 'last_modified' in db_columns:
        db_columns.remove('last_modified')
    
    if len(df_list) > 1:
        df, list_of_columns_found = handle_multi_sheet_xl(df_list, db_columns, table_name)
        print(df, list_of_columns_found)
    else:
        df = df_list[0]
    
    if df.empty:
        send_column_missing_email(db_columns, list_of_columns_found, key)
        return "failed"
    
    # Renamming columns
    df = df.rename(columns=RENAME_DICT[table_name])
    
    # Adding 0 in place of nan in numeric fields
    # df[non_char_fields] = df[non_char_fields].fillna(0)
    non_char_fields = list(existing_df.select_dtypes(include=['number']).columns)
    if "duplicate_count" in non_char_fields:
        non_char_fields.remove("duplicate_count")
    if "upload_date" in non_char_fields:
        non_char_fields.remove('upload_date')
    
    file_columns = list(df.columns)
    print("Printing columns found in file ....")
    print(file_columns)
    
    ### Check if all columns are present
    if set(file_columns) != set(db_columns):
        email_message = send_column_missing_email(db_columns, file_columns, key)
        return email_message
    
    irregularities = check_dtypes_and_return_irregularities(df, non_char_fields)
    # Check if all columns have the right dtype
    if len(irregularities) != 0:
        send_dtype_error_email(irregularities, key)
        # return "failed"
    
    print('All columns are present')
    print('No irregularities in dtype')
    
    # df = df.drop_duplicates()
    df = df.drop_duplicates(subset=key_columns)
    
    # Add current time to df
    df["last_modified"] = datetime.today().strftime('%d-%m-%Y %H:%M:%S')
    
    # datetime_in_unix = int(time.time()) 
    # df["upload_date"] = datetime_in_unix
    
    final_df, inner_df = compare_and_append_df(existing_df, df, backup_df, key_columns)
    if "duplicate_count" in final_df.columns:
        # final_df["duplicate_count"] = final_df["duplicate_count"].astype(int)
        final_df["duplicate_count"] = 0
        

    final_df.to_sql(table_name, engine, if_exists='append', index=False)
    
    if inner_df.shape[0] != 0:
        # UPDATING
        string = ""
        col_list = list(set(inner_df.columns) - {"id"} - set(key_columns))
        for col in col_list:
            if col == col_list[-1]:
                string = string + f"{col} = t.{col} \n"
                continue
            string = string + f"{col} = t.{col}, \n"
            
        string_key_columns = ""
        for col in key_columns:
            if col == key_columns[-1]:
                string_key_columns += f"\"f\".\"{col}\" = \"t\".\"{col}\"; \n" 
            else:
                string_key_columns += f"\"f\".\"{col}\" = \"t\".\"{col}\" AND " 
        
        temp_table_name = f"{table_name}_temp"
        update_table_sql = f""" UPDATE \"{table_name}\" f SET
                                {string}
                                FROM \"{temp_table_name}\" t
                                WHERE {string_key_columns}
                            """
        # Connect to db using psycopg2
        conn = psycopg2.connect(
          database=DATABASE, user=USERNAME, password=PASSWORD, host=HOST, port=PORT
        )
        cursor = conn.cursor()
        
        try:
            create_table_sql = f"CREATE TABLE \"{temp_table_name}\" (LIKE \"{table_name}\" INCLUDING ALL) ;"
            cursor.execute(create_table_sql)
            conn.commit()
            inner_df['id'] = inner_df.index
            if "duplicate_count" in inner_df.columns:
                inner_df['duplicate_count'] = 0
            inner_df.to_sql(temp_table_name, engine, if_exists='append', index=False)
            
            print(update_table_sql)
            print(string_key_columns)
        
            with conn:
                with conn.cursor() as cur:
                    cur.execute(update_table_sql)
                    cur.execute(f"DROP TABLE \"{temp_table_name}\"; ")
        
        except Exception as e:
            print(e)
            print(traceback.format_exc())
            with conn:
                with conn.cursor() as cur:
                    cur.execute(f"DROP TABLE \"{temp_table_name}\"; ")
            
        
        conn.commit()
        conn.close()


def send_data_to_db_main(filename, folder):
    
    bucket = "integrace-data-lake"
    key = f"{folder}/{filename}"
    df = get_data_and_key_from_bucket(key, bucket)
    
    if folder == 'IBIS_employee_master':
        table_name = "IBIS_employee_master"
        key_columns = ["organogram_code", "organogram_name"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'IBIS_pob_register':
        table_name = 'IBIS_pob_register_may'
        key_columns = ["doc_no", "product_code", "total_pob_value"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'IBIS_product_master':
        table_name = 'IBIS_product_master'
        key_columns = ["product_code", "productid"]
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if folder == 'IBIS_organogram_master':
        table_name = 'IBIS_organogram_master_from_xl'
        key_columns = ["fsocode", "fsoname"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'IBIS_location_master':
        table_name = 'IBIS_location_master'
        key_columns = ["location_i_d", "location_code"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'IBIS_customer_master':
        table_name = 'IBIS_customer_master'
        key_columns = ["territory_code", "customer_code", "division_name", "address_type"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'IBIS_hierarchy_master':
        table_name = 'IBIS_hierarchy_master'
        key_columns = ["terrcode", "terrname2"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'IBIS_institution_master':
        table_name = 'IBIS_institution_master'
        key_columns = ['code']
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'IBIS_budget_details':
        table_name = 'IBIS_budget_details'
        key_columns = ["territory_code", "product_code", 'year_name', 'month_name']
        response = send_data_to_db(df, key, table_name, key_columns)

    if folder == 'IBIS_mrm_brand':   
        table_name = 'IBIS_mrm_brand' 
        key_columns = ['divisionid', 'brandid']
        response = send_data_to_db(df, key, table_name, key_columns)
       
    if folder == 'Iforce_employee_master':
        table_name = 'Iforce_employee_master'
        key_columns = ["positionid", "sap_code"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'bandhan_chemist_data':
        table_name = 'bandhan_chemist_data'
        key_columns = ["fso_id", "chemist_name", "date", "total_coupons"]
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if folder == 'bandhan_patient_list':
        key_columns = ["first_name", "coupon_code"]
        table_name = 'bandhan_patient_list'
        
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if folder == 'bandhan_technician_data':
        table_name = 'bandhan_technician_data'
        key_columns = ["mobile_number"]
        response = send_data_to_db(df, key, table_name, key_columns)
    

        
    ############ LATEST DATA from Integrace 21-July
    if folder == 'Iforce_doctordata':   
        table_name = 'Iforce_doctordata_2021_07_17'
        key_columns = ["sbu_code"]
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if folder == 'Iforce_chemistdata':  
        table_name = 'Iforce_chemistdata_2021_07_20'  
        key_columns = ["chemistname", "contactname", "phone", "mobile"]
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if folder == 'IBIS_pob_product_master':  
        table_name = 'IBIS_pob_product_master' 
        key_columns = ["productcode"]
        response = send_data_to_db(df, key, table_name, key_columns)

    if folder == 'IBIS_pob_product_price_master':
        table_name = 'IBIS_pob_product_price_master'  
        key_columns = ["productcode"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'Iforce_position_master':  
        table_name = 'Iforce_position_master' 
        key_columns = ["position_id", "employee_code", "orgonogram_code"]
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'Iforce_rcpa':  
        table_name = 'Iforce_rcpa_june_month'  
        key_columns = ["rcpa_date", 'sbu_code', 'brand']
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if folder == 'Iforce_kyc_details': 
        df[0] = df[0].rename(columns=lambda x: x.strip()) # ----------------------------------------------CHECK----------------------------
        key_columns = ['doctor_name', 'mobile_number', 'sbu_code']
        table_name = 'Iforce_kyc_details'  
        response = send_data_to_db(df, key, table_name, key_columns)

    if folder == 'IBIS_sos_details_gynae':
        table_name = 'IBIS_sos_details_gynae' 
        key_columns = ["stockiest_code", 'product_code', 'territory_code']
        response = send_data_to_db(df, key, table_name, key_columns)

    if folder == 'IBIS_sos_details_ortho':    
        table_name = 'IBIS_sos_details_ortho'
        key_columns = ["stockiest_code", 'product_code', 'territory_code']
        response = send_data_to_db(df, key, table_name, key_columns)
    
    #####
        # Latest files uploaded in August
    #####

    if folder == 'Iforce_dcr_brandwise':    
        table_name = 'Iforce_dcr_brandwise'
        key_columns = ["doctor_id", 'visit_date', 'brand_prescribed']
        response = send_data_to_db(df, key, table_name, key_columns)

    if folder == 'Iforce_doctorwisemapped': 
        key_columns = ['doctor_id', 'mapped_date', 'delivered_date', 'mapped_input_name', 'year', 'month']
        table_name = 'Iforce_doctorwisemapped'
        response = send_data_to_db(df, key, table_name, key_columns)
        
    if folder == 'Iforce_mtp_master_dsm':    
        table_name = 'Iforce_mtp_master_dsm'
        key_columns = ['mtpdate', 'sbucode']
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if folder == 'IBIS_secondary_sales':    
        table_name = 'IBIS_secondary_sales_mar21'
        key_columns = ["product_code", "territory_code", "stockist_code", "month"]
        response = send_data_to_db(df, key, table_name, key_columns)
    
    if response == None:
        response = "All Files uploaded successfully!"
    return response