

def get_folder_name(attachment_filename):

    remove_list = ['.', '-', '_', '(', ')', 'location', 'master', 'csv', 'xlsx', 'xls', 'xlsd']

    attachment_filename = attachment_filename.lower()
    for word in remove_list:
        fn = attachment_filename.replace(word, ' ').strip()
        attachment_filename = fn

    print(f'Final preprocessed file name --{fn}--')
    
    if 'bandhan' in fn and ('chemist' in fn or 'chemistdata' in fn):
        bucket_folder_name = 'bandhan_chemist_data'
    
    elif 'patient' in fn:
        bucket_folder_name = 'bandhan_patient_list'

    elif 'technician' in fn:
        bucket_folder_name = 'bandhan_technician_data'

    elif 'budget' in fn:
        bucket_folder_name = 'IBIS_budget_details'

    elif 'customer' in fn:
        bucket_folder_name = 'IBIS_customer_master'

    elif 'distribution' in fn :
        bucket_folder_name = 'IBIS_distribution_master_location'

    elif 'employee' in fn and 'ibis' in fn:
        bucket_folder_name = 'IBIS_employee_master'

    elif 'hierarchy' in fn:
        bucket_folder_name = 'IBIS_hierarchy_master'

    elif 'institution' in fn:
        bucket_folder_name = 'IBIS_institution_master'

    elif 'location' in fn:
        bucket_folder_name = 'IBIS_location_master'

    elif 'mrm' in fn:
        bucket_folder_name = 'IBIS_mrm_brand'

    elif 'organogram' in fn:
        bucket_folder_name = 'IBIS_organogram_master'

    # elif 'pob' in fn:
    #     bucket_folder_name = 'IBIS_pob_product_master'

    #####
    elif 'pob' in fn and 'price' in fn:
        bucket_folder_name = 'IBIS_pob_product_price_master'

    elif 'pob' in fn and 'register' in fn:
        bucket_folder_name = 'IBIS_pob_register'

    elif 'product' in fn:
        bucket_folder_name = 'IBIS_product_master'

    elif 'gynae' in fn and 'sos' in fn:
        bucket_folder_name = 'IBIS_sos_details_gynae'

    elif 'ortho' in fn and 'sos' in fn:
        bucket_folder_name = 'IBIS_sos_details_ortho'

    elif 'stockiest' in fn:
        bucket_folder_name = 'IBIS_stockiest_master_customer'

    #####
    elif 'iforce' in fn and ('chemist' in fn or 'chemistdata' in fn):
        bucket_folder_name = 'Iforce_chemistdata'

    elif 'dcr' in fn and 'brandwise' in fn:
        bucket_folder_name = 'Iforce_dcr_brandwise'

    elif 'doctordata' in fn:
        bucket_folder_name = 'Iforce_doctordata'

    elif 'doctorwisemapped' in fn:
        bucket_folder_name = 'Iforce_doctorwisemapped'

    elif 'employee' in fn and 'iforce' in fn:
        bucket_folder_name = 'Iforce_employee_master'

    elif 'kyc' in fn:
        bucket_folder_name = 'Iforce_kyc_details'

    elif 'mtp' in fn:
        bucket_folder_name = 'Iforce_mtp_master_dsm'

    elif 'position' in fn:
        bucket_folder_name = 'Iforce_position_master'

    elif 'rcpa' in fn:
        bucket_folder_name = 'Iforce_rcpa'

    elif 'primary' in fn:
        bucket_folder_name = 'primary_sales_data'

    elif 'boot_internationl_2020' in fn:
        bucket_folder_name = 'webinar_boot_internationl_2020'

    elif 'boot_internationl_2021' in fn:
        bucket_folder_name = 'webinar_boot_internationl_2021'

    elif 'ertm' in fn:
        bucket_folder_name = 'webinar_ertm'

    elif 'origyn' in fn:
        bucket_folder_name = 'webinar_origyn'

    elif 'vkonnect' in fn:
        bucket_folder_name = 'webinar_vkonnect'

    

    return bucket_folder_name