from boto3.s3.transfer import S3Transfer
import boto3
# from rename_dicts import RENAME_DICT

#have all the variables populated which are required below
access_key = 'AKIA6OXT4V7WSYQSWBEL'
secret_key = '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'
client = boto3.client('s3', aws_access_key_id=access_key, aws_secret_access_key=secret_key)


def send_to_s3(bucket_folder_name, download_folder, attachment_filename):

    bucket_name = 'integrace-data-lake'

    filename = r"{download_folder}/{attachment_filename}".format(download_folder = download_folder, attachment_filename = attachment_filename)
    testfile = r"{attachment_filename}".format(attachment_filename = attachment_filename)

    transfer = S3Transfer(client)
    print('Uploading %s to Amazon S3 bucket %s/%s' % (attachment_filename, bucket_name, bucket_folder_name))
    transfer.upload_file(filename, bucket_name, bucket_folder_name+"/"+testfile)
