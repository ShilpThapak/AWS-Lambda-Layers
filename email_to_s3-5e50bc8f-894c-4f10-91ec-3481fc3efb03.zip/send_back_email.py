import time
import json

import email

import imaplib

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib
import mimetypes
import email.mime.application



def send_mail(sender, sendback_response):
    
    print('EMAIL ====== :', sender)

    email_bot = 'test.markytics.integrace@gmail.com'
    email_pass = 'password@12312'

    smtp_ssl_host = 'smtp.gmail.com'
    smtp_ssl_port = 465
    s = smtplib.SMTP_SSL(smtp_ssl_host, smtp_ssl_port)
    s.login(email_bot, email_pass)

    msg = MIMEMultipart()
    msg['Subject'] = 'Regarding the File uploaded for data transfer to DATABASE'
    msg['From'] = 'Integrace IT Administrator'        
    msg['To'] = sender

    txt = sendback_response


    print(txt)

    txt = MIMEText(txt)
    msg.attach(txt)
    s.send_message(msg)
    print('Message successfully sent')
    s.quit()