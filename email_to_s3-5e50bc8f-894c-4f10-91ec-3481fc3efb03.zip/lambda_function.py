from imbox import Imbox # pip install imbox
import traceback

from send_to_s3 import *
from get_s3_folder_name import *


##### For Google download
import requests
import wget
import os
from os.path import expanduser
#####

import re

########### Email Connection #############
import imaplib, email, getpass
import base64
import os

from send_back_email import *

from email import policy
from s3_to_rds_transfer import send_data_to_db_main
import boto3

client = boto3.client('stepfunctions')
host = "imap.gmail.com"
username = "test.markytics.integrace@gmail.com"
password = 'password@12312'
# download_folder = r"""C:\Users\Ajay\projects\automation\email_to_rds"""
# download_folder = '/var/task'

download_folder = '/tmp'
directory = download_folder

# mail = Imbox(host, username=username, password=password, ssl=True, ssl_context=None, starttls=False)
############ End Email Connection ############

def call_s3_to_rds_lambda(bucket_folder_name, attachment_filename, sender):
    print(bucket_folder_name, attachment_filename, sender)
    message = send_data_to_db_main(attachment_filename, bucket_folder_name)
    send_mail(sender, message)
    print(message)
    

def get_drive_links(message_body):
    alllinks = [x.group() for x in re.finditer( r"https://drive.google.com(.*)=drive_web", message_body)]
    
    return alllinks
    
    # return re.sub('[^A-Za-z0-9]+', '', message_body)

def lambda_handler(event, context):
###### Download atachments #############
    mail = Imbox(host, username=username, password=password, ssl=True, ssl_context=None, starttls=False)
    if not os.path.isdir(download_folder):
        os.makedirs(download_folder, exist_ok=True)
        
    messages = mail.messages(unread = True)
    keys = []
    # messages = mail.messages()

    print(f'---Number of new messages = {len(messages)}---')

    if len(messages) == 0:
        print("No new message arrived.")

    else:
        for (uid, message) in messages:

            file_in_drive = False
            mail.mark_seen(uid) # optional, mark message as read

            subject = message.subject
            sender = message.sent_from[0]['email']
            message_body = message.body['plain'][0]
            parsed_date = message.parsed_date

            # print(f'-----{parsed_date}-----')
            # print(f'-----{subject}-----{sender}---------{message_body}------')

            if 'https://drive.google.com' in message_body:
                file_in_drive = True

            if len(message.attachments) == 0 and file_in_drive == False:
                print('no attachment')
                # sendback_response = f'Hello Sir, the mail from you with SUBJECT : "({subject})" sent at {parsed_date} contains no attachment. Please re-send the mail with attaching proper file.'
                sendback_response = f'The mail you sent contains no attachment. Please attach the file and send the mail again.'
                send_mail(sender, sendback_response)
            
            else:
                try:
                    if file_in_drive == True:
                        print('Drive file')
                        alllinks = get_drive_links(message_body)

                        for link in alllinks:
                            link = link.replace('https://drive.google.com/file/d/', 'https://drive.google.com/u/0/uc?id=').replace('/view?usp=drive_web', '&export=download')
                            print(f'Link : -----{link}-----')
                            
                            ##### 
                            
                            myhome = expanduser(download_folder)
                            os.chdir(myhome)
                            url = link
                            querystring = {"alt":"media","export":"download"}

                            headers = {
                                'Authorization': "Bearer TOKEN",

                                'Host': "www.googleapis.com",
                                'Accept-Encoding': "gzip, deflate",
                                'Connection': "keep-alive",
                                }

                            response = requests.request("GET", url, headers=headers, params=querystring)
                            #####
                            attachment_filename = wget.download(response.url)
                            print(f'FileName : --{attachment_filename}--')
                            download_path = f"{download_folder}/{attachment_filename}"
                            bucket_folder_name = get_folder_name(attachment_filename)

                            #### Step 2
                            #### Upload File to S3 Bucket ##########
                            try:
                                send_to_s3(bucket_folder_name, download_folder, attachment_filename)
                                print(f'{attachment_filename} - Uploaded to S3 Successfully ')
                                file_upload_status = True
                                key = f"{bucket_folder_name}/{attachment_filename}"
                                key_dict = {
                                    "key": key,
                                    "sender": sender,
                                    "status_code": 200,
                                    "message": "File to be transfered to db",
                                }
                                keys.append(key_dict)
                            except:
                                file_upload_status = False
                                print("S3 upload failure")
                                sendback_response = 'File upload failed! Please rename the file based on the guidelines discussed and upload again.'
                                # send_mail(sender, sendback_response)
                                key = f"unknown_folder/{attachment_filename}"
                                key_dict = {
                                    "key": key,
                                    "sender": sender,
                                    "status_code": 500,
                                    "message": sendback_response,
                                }
                                keys.append(key_dict)

                            # try:
                            #     time.sleep(5)
                            #     email_message = call_s3_to_rds_lambda(bucket_folder_name, attachment_filename, sender)
                            # except Exception as e:
                            #     print(e)
                            #     print(traceback.print_exc())
                            #     message = traceback.ex
                            #     print('ERROR in calling - call_s3_to_rds_lambda')
                            
                            #### Delete from local machine ##########
                            try:
                                if os.path.isfile(f"{download_folder}/{attachment_filename}") and file_upload_status == True:
                                    os.remove(f"{download_folder}/{attachment_filename}")
                                    print(f'{attachment_filename} - Deleted from local machine Successfully ')
                            except:
                                print(f'{attachment_filename} - NOT FOUND for deleting')
                    
                except:
                    print('Drive Download error')
                    sendback_response = f'Hello Sir, the mail from you with SUBJECT : "({subject})" sent at {parsed_date} contains attachment as Google Drive link. We are unable to fetch the file - "{attachment_filename}" due to "view only" permission given to file. Please resent the file providing - "Turn link sharing on"'
                    # send_mail(sender, sendback_response)
                    key = f"{bucket_folder_name}/{attachment_filename}"
                    key_dict = {
                                    "key": key,
                                    "sender": sender,
                                    "status_code": 500,
                                    "message": sendback_response,
                                }
                    keys.append(key_dict)

                for idx, attachment in enumerate(message.attachments):
                    try:
                        # print(f'-----{idx}----------{attachment}----------{enumerate(message.attachments)} -----')
                        attachment_filename = attachment.get('filename')
                        download_path = f"{download_folder}/{attachment_filename}"
                        # download_path = attachment_filename
                        print(f'\n--{attachment_filename}--')
                        print(download_path)
                        with open(download_path, "wb") as fp:
                            fp.write(attachment.get('content').read())


                        bucket_folder_name = get_folder_name(attachment_filename)

                        print(bucket_folder_name)
                        ##### Step 2
                        ##### Upload File to S3 Bucket ##########
                        try:
                            send_to_s3(bucket_folder_name, download_folder, attachment_filename)
                            print(f'{attachment_filename} - Uploaded to S3 Successfully ')
                            file_upload_status = True
                            key = f"{bucket_folder_name}/{attachment_filename}"
                            key_dict = {
                                    "key": key,
                                    "sender": sender,
                                    "status_code": 200,
                                    "message": "File to be transfered to db",
                                }
                            keys.append(key_dict)
                        except:
                            file_upload_status = False
                            print("S3 upload failure")
                            # sendback_response = f'Hello Sir, the mail from you with SUBJECT : "({subject})" sent at {parsed_date} was unable to upload to database. The file "{attachment_filename}" got an error while uploading. Please try to resend the mentioned file with proper method.'
                            # send_mail(sender, sendback_response)
                            sendback_response = 'File upload failed! Please rename the file based on the guidelines discussed and upload again.'
                            key = f"unknown_folder/{attachment_filename}"
                            key_dict = {
                                    "key": key,
                                    "sender": sender,
                                    "status_code": 500,
                                    "message": sendback_response,
                                }
                            keys.append(key_dict)

                        # try:
                        #     time.sleep(5)
                        #     call_s3_to_rds_lambda(bucket_folder_name, attachment_filename, sender)
                        # except:
                        #     print(traceback.print_exc())
                        #     print('ERROR in calling - call_s3_to_rds_lambda')

                        ##### Delete from local machine ##########
                        try:
                            if os.path.isfile(f"{download_folder}/{attachment_filename}") and file_upload_status == True:
                                os.remove(f"{download_folder}/{attachment_filename}")
                                print(f'{attachment_filename} - Deleted from local machine Successfully ')
                        except Exception as e:
                            print(e)
                            print(traceback.print_exc())
                            print(f'{attachment_filename} - NOT FOUND for deleting')
                        
                    except:
                        print('Exception *****')
                        print(traceback.print_exc())
                        sendback_response = 'File upload failed! Please rename the file based on the guidelines discussed and upload again.'
                        # sendback_response = f'Hello Sir, the mail from you with SUBJECT : "({subject})" sent at {parsed_date} was unable to upload to database. The file "{attachment_filename}" got an error while uploading. Please try to resend the mentioned file with proper method.'
                        # send_mail(sender, sendback_response)
                        key = f"unknown_folder/{attachment_filename}"
                        key_dict = {
                                "key": key,
                                "sender": sender,
                                "status_code": 500,
                                "message": sendback_response,
                            }
                        keys.append(key_dict)

    mail.logout()
    ######## End download attachments ######

    print("\nEND OF PROCESSING\n")
    
    # keys = ["first", "second", "third"]
    # keys = list(map(json.dumps, keys))
    # response = client.start_execution(
    #         stateMachineArn='arn:aws:states:ap-south-1:993722675181:stateMachine:MyStateMachine',
    #         input= json.dumps(keys)
    #     )
    
    
    if len(keys) > 0:
        response = client.start_execution(
            stateMachineArn='arn:aws:states:ap-south-1:993722675181:stateMachine:MyStateMachine',
            input= json.dumps(keys)
        )
    
    
       
    # {
    # "age" : $input.json('$.persondata.age'),
    # "income" : $input.json('$.persondata.income')
    # "height" : $input.json('$.persondata.height')
    # } 
    # keys = [$input.json('$.persondata.age'), $input.json('$.persondata.income'), $input.json('$.persondata.height')]
    # keys = ["1", "2", "3", "4"]    
    # response = client.start_execution(
    #         stateMachineArn='arn:aws:states:ap-south-1:993722675181:stateMachine:MyStateMachine',
    #         input= json.dumps(keys)
    #     )

    return event