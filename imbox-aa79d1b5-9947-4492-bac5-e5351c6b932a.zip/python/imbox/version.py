__version__ = "0.9.8"
VERSION = __version__.split('.')
