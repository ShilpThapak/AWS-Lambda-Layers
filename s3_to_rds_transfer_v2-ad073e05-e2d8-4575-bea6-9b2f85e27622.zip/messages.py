"""
Your module description
"""
SUBJECT = 'An error occured while uploading your file to S3 bucket "integrace-data-lake"'

TIPS_MESSAGE = "Please read the following tips to fix this issue and upload the file again: \n"

INCORRECT_COLUMNS_TIP = "1. Make sure that you upload the file in the correct folder. \n" \
                        "2. Remove any additional columns you might have added. \n" \
                        "3. Check if all the columns are named correctly in your file. \n" \
                        "Here is a list of columns that should be present in your file: "