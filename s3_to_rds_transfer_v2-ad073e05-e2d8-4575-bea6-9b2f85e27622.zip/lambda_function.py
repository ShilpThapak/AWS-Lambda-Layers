"""
Requirements:
pandas
psycopg2
xlrd
openpyxl
sqlalchemy
"""
from worker import main
import traceback
import json


def lambda_handler(event, context):
    try:
        res = main(event)
        return res
        
    except Exception as e:
        error = traceback.format_exc()
        print(error)
        print(e)
        # SNS - unexpected error
        return {
            "statusCode": 500,
            "headers": None,
            "body": "Internal Server Error",
            "isBase64Encoded": False,
        }
